package com.cg.donor.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.donor.bean.DonorBean;
import com.cg.donor.exception.DonorException;
import com.cg.donor.util.DBConnection;

public class DonorDaoImpl implements IDonorDAO
{

	@Override
	public String addDonor(DonorBean donor) throws DonorException, ClassNotFoundException, IOException, SQLException {
	 
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		
		ResultSet resultSet=null;
		 String donorId=null;
		 int queryResult=0;
		 try {
			 
			preparedStatement=connection.prepareStatement("insert into Donor_details values(donorId_sequence.nextval,?,?,?,SYSDATE,?)");
			
			preparedStatement.setString(1,donor.getDonorName() );
			preparedStatement.setString(2,donor.getPhoneNumber() );
			preparedStatement.setString(3,donor.getAddress());
			preparedStatement.setDouble(4,donor.getDonationAmount());
			preparedStatement.executeUpdate();
			 Statement st=connection.createStatement();
			resultSet=st.executeQuery("Select max(donor_id) from Donor_details");
			if(resultSet.next()) {
				donorId=resultSet.getString(1);
				}
		} catch (Exception sql) {
			sql.printStackTrace();
			// TODO: handle exception
		}
		
		
		return donorId;
	}

	@Override
	public DonorBean viewDonorDetails(String donorId) throws DonorException,Exception {
		DonorBean bean=null;
		Connection connection=DBConnection.getConnection();
		try {
		Statement st=connection.createStatement();
		ResultSet rs=st.executeQuery("select * from Donor_details where donor_Id='"+donorId+"'");
		bean=new DonorBean();
		while(rs.next()) {
			bean.setDonorId(rs.getString(1));
			bean.setDonorName(rs.getString(2));
			bean.setAddress(rs.getString(3));
			bean.setPhoneNumber(rs.getString(4));
			bean.setDonationDate(rs.getDate(5));
			bean.setDonationAmount(rs.getDouble(6));

			}
	} catch (Exception sql) 
		{
		sql.printStackTrace();
		
	}
		
		return bean;
	}

	@Override
	public List retriveAll() throws DonorException, ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=DBConnection.getConnection();
		List<DonorBean> li=new ArrayList<>();
		try {
		Statement st=connection.createStatement();
		ResultSet rs=st.executeQuery("select * from Donor_details ");
		
		while(rs.next()) {
			DonorBean bean=new DonorBean();

bean.setDonorId(rs.getString(1));
bean.setDonorName(rs.getString(2));
bean.setAddress(rs.getString(3));
bean.setPhoneNumber(rs.getString(4));
bean.setDonationDate(rs.getDate(5));
bean.setDonationAmount(rs.getDouble(6));
li.add(bean);
			}
	} catch (Exception sql) 
		{
		sql.printStackTrace();
		
	}
		return li;
	}

}
